// Servicio para interactuar con la API de Google Books
export class GoogleBooksAPI {
  constructor() {
    this.baseURL = 'https://www.googleapis.com/books/v1/volumes'
    this.maxResults = 10
  }

  // Buscar libros en Google Books API
  async buscarLibros(query) {
    if (!query || query.trim().length < 2) {
      return []
    }

    try {
      const searchQuery = encodeURIComponent(query.trim())
      const url = `${this.baseURL}?q=${searchQuery}&maxResults=${this.maxResults}&langRestrict=es`
      
      const response = await fetch(url)
      
      if (!response.ok) {
        throw new Error(`Error en la API: ${response.status}`)
      }

      const data = await response.json()
      
      if (!data.items) {
        return []
      }

      return data.items.map(item => this.formatearLibro(item))
    } catch (error) {
      console.error('Error al buscar libros:', error)
      throw new Error('No se pudo conectar con la API de Google Books')
    }
  }

  // Formatear datos del libro desde la API
  formatearLibro(item) {
    const volumeInfo = item.volumeInfo || {}
    
    return {
      id: item.id,
      titulo: volumeInfo.title || 'Título no disponible',
      autor: volumeInfo.authors ? volumeInfo.authors.join(', ') : 'Autor desconocido',
      genero: volumeInfo.categories ? volumeInfo.categories[0] : 'Sin género',
      año: volumeInfo.publishedDate ? parseInt(volumeInfo.publishedDate.substring(0, 4)) : null,
      portada: this.obtenerPortada(volumeInfo.imageLinks),
      descripcion: volumeInfo.description || 'Sin descripción disponible',
      editorial: volumeInfo.publisher || 'Editorial desconocida',
      paginas: volumeInfo.pageCount || null,
      isbn: this.obtenerISBN(volumeInfo.industryIdentifiers),
      idioma: volumeInfo.language || 'es',
      estado: 'disponible'
    }
  }

  // Obtener la mejor portada disponible
  obtenerPortada(imageLinks) {
    if (!imageLinks) {
      return 'https://images.pexels.com/photos/1029141/pexels-photo-1029141.jpeg?auto=compress&cs=tinysrgb&w=300'
    }

    // Priorizar imágenes de mayor calidad
    return imageLinks.large || 
           imageLinks.medium || 
           imageLinks.small || 
           imageLinks.thumbnail || 
           imageLinks.smallThumbnail ||
           'https://images.pexels.com/photos/1029141/pexels-photo-1029141.jpeg?auto=compress&cs=tinysrgb&w=300'
  }

  // Obtener ISBN del libro
  obtenerISBN(identifiers) {
    if (!identifiers) return null
    
    const isbn13 = identifiers.find(id => id.type === 'ISBN_13')
    const isbn10 = identifiers.find(id => id.type === 'ISBN_10')
    
    return isbn13?.identifier || isbn10?.identifier || null
  }

  // Obtener detalles completos de un libro específico
  async obtenerDetallesLibro(bookId) {
    try {
      const url = `${this.baseURL}/${bookId}`
      const response = await fetch(url)
      
      if (!response.ok) {
        throw new Error(`Error al obtener detalles: ${response.status}`)
      }

      const data = await response.json()
      return this.formatearLibro(data)
    } catch (error) {
      console.error('Error al obtener detalles del libro:', error)
      throw new Error('No se pudieron obtener los detalles del libro')
    }
  }
}