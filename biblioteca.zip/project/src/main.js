import './style.css'
import { BibliotecaManager } from './biblioteca.js'

// Inicializar la aplicación
document.querySelector('#app').innerHTML = `
  <div class="biblioteca-container">
    <header class="header">
      <h1>📚 Biblioteca Digital</h1>
      <p>Gestiona tu colección de libros</p>
    </header>

    <div class="main-content">
      <!-- Formulario para agregar libros -->
      <section class="add-book-section">
        <div class="section-tabs">
          <button class="tab-button active" onclick="biblioteca.cambiarTab('manual')">📝 Agregar Manualmente</button>
          <button class="tab-button" onclick="biblioteca.cambiarTab('api')">🔍 Buscar en Google Books</button>
        </div>
        
        <!-- Pestaña de búsqueda en API -->
        <div id="api-tab" class="tab-content" style="display: none;">
          <h3>Buscar libros en Google Books</h3>
          <div class="api-search-container">
            <div class="api-search-box">
              <input type="text" id="api-search-input" placeholder="Buscar por título, autor, ISBN...">
              <button id="close-api-results" class="close-api-btn" style="display: none;">✕</button>
            </div>
            <div id="api-loading" class="api-loading" style="display: none;">
              <div class="loading-spinner"></div>
              <p>Buscando libros...</p>
            </div>
            <div id="api-results" class="api-results" style="display: none;">
              <!-- Resultados de la API aparecerán aquí -->
            </div>
          </div>
        </div>
        
        <!-- Pestaña manual -->
        <div id="manual-tab" class="tab-content">
          <h3>Agregar libro manualmente</h3>
        <form id="book-form" class="book-form">
          <div class="form-group">
            <input type="text" id="titulo" placeholder="Título del libro" required>
            <input type="text" id="autor" placeholder="Autor" required>
          </div>
          <div class="form-group">
            <input type="text" id="genero" placeholder="Género">
            <input type="number" id="año" placeholder="Año de publicación" min="1000" max="2024">
          </div>
          <div class="form-group">
            <input type="url" id="portada" placeholder="URL de la portada (opcional)">
            <select id="estado">
              <option value="disponible">Disponible</option>
              <option value="prestado">Prestado</option>
              <option value="reservado">Reservado</option>
            </select>
          </div>
          <div class="preview-container">
            <div id="preview-add" class="image-preview-box">
              <p class="preview-placeholder">Vista previa de la portada aparecerá aquí</p>
            </div>
          </div>
          <button type="submit" class="btn-primary">Agregar Libro</button>
        </form>
        </div>
      </section>

      <!-- Barra de búsqueda y filtros -->
      <section class="search-section">
        <div class="search-controls">
          <input type="text" id="search-input" placeholder="Buscar por título, autor o género...">
          <select id="filter-estado">
            <option value="">Todos los estados</option>
            <option value="disponible">Disponible</option>
            <option value="prestado">Prestado</option>
            <option value="reservado">Reservado</option>
          </select>
          <select id="sort-by">
            <option value="titulo">Ordenar por Título</option>
            <option value="autor">Ordenar por Autor</option>
            <option value="año">Ordenar por Año</option>
          </select>
        </div>
      </section>

      <!-- Estadísticas -->
      <section class="stats-section">
        <div class="stats-grid">
          <div class="stat-card">
            <span class="stat-number" id="total-libros">0</span>
            <span class="stat-label">Total de Libros</span>
          </div>
          <div class="stat-card">
            <span class="stat-number" id="libros-disponibles">0</span>
            <span class="stat-label">Disponibles</span>
          </div>
          <div class="stat-card">
            <span class="stat-number" id="libros-prestados">0</span>
            <span class="stat-label">Prestados</span>
          </div>
        </div>
      </section>

      <!-- Lista de libros -->
      <section class="books-section">
        <h2>Mi Biblioteca</h2>
        <div id="books-container" class="books-grid">
          <!-- Los libros se cargarán aquí dinámicamente -->
        </div>
        <div id="empty-state" class="empty-state" style="display: none;">
          <h3>📖 Tu biblioteca está vacía</h3>
          <p>Comienza agregando tu primer libro usando el formulario de arriba</p>
        </div>
      </section>
    </div>
  </div>

  <!-- Modal para editar libro -->
  <div id="edit-modal" class="modal">
    <div class="modal-content">
      <span class="close">&times;</span>
      <h2>Editar Libro</h2>
      <form id="edit-form" class="book-form">
        <div class="form-group">
          <input type="text" id="edit-titulo" placeholder="Título del libro" required>
          <input type="text" id="edit-autor" placeholder="Autor" required>
        </div>
        <div class="form-group">
          <input type="text" id="edit-genero" placeholder="Género">
          <input type="number" id="edit-año" placeholder="Año de publicación" min="1000" max="2024">
        </div>
        <div class="form-group">
          <input type="url" id="edit-portada" placeholder="URL de la portada (opcional)">
          <select id="edit-estado">
            <option value="disponible">Disponible</option>
            <option value="prestado">Prestado</option>
            <option value="reservado">Reservado</option>
          </select>
        </div>
        <div class="preview-container">
          <div id="preview-edit" class="image-preview-box">
            <p class="preview-placeholder">Vista previa de la portada aparecerá aquí</p>
          </div>
        </div>
        <button type="submit" class="btn-primary">Guardar Cambios</button>
      </form>
    </div>
  </div>
`

// Inicializar el gestor de biblioteca
const biblioteca = new BibliotecaManager()
window.biblioteca = biblioteca