export class BibliotecaManager {
  constructor() {
    this.googleBooksAPI = new GoogleBooksAPI()
    this.libros = this.cargarLibros()
    this.libroEditando = null
    this.searchTimeout = null
    this.inicializarEventos()
    this.renderizarLibros()
    this.actualizarEstadisticas()
  }

  // Cambiar entre pestañas
  cambiarTab(tab) {
    const manualTab = document.getElementById('manual-tab')
    const apiTab = document.getElementById('api-tab')
    const tabButtons = document.querySelectorAll('.tab-button')
    
    // Remover clase active de todos los botones
    tabButtons.forEach(btn => btn.classList.remove('active'))
    
    if (tab === 'manual') {
      manualTab.style.display = 'block'
      apiTab.style.display = 'none'
      tabButtons[0].classList.add('active')
      this.cerrarResultadosAPI()
    } else {
      manualTab.style.display = 'none'
      apiTab.style.display = 'block'
      tabButtons[1].classList.add('active')
    }
  }

  // Buscar libros en Google Books API
  async buscarEnAPI(query) {
    const loadingEl = document.getElementById('api-loading')
    const resultsEl = document.getElementById('api-results')
    const closeBtn = document.getElementById('close-api-results')

    // Limpiar timeout anterior
    if (this.searchTimeout) {
      clearTimeout(this.searchTimeout)
    }

    // Si la query está vacía, ocultar resultados
    if (!query || query.trim().length < 2) {
      loadingEl.style.display = 'none'
      resultsEl.style.display = 'none'
      closeBtn.style.display = 'none'
      return
    }

    // Mostrar loading después de un pequeño delay para evitar búsquedas excesivas
    this.searchTimeout = setTimeout(async () => {
      try {
        loadingEl.style.display = 'block'
        resultsEl.style.display = 'none'
        closeBtn.style.display = 'inline-block'

        const libros = await this.googleBooksAPI.buscarLibros(query)
        
        loadingEl.style.display = 'none'
        this.mostrarResultadosAPI(libros)
        
      } catch (error) {
        loadingEl.style.display = 'none'
        this.mostrarErrorAPI(error.message)
      }
    }, 500) // Delay de 500ms para evitar demasiadas peticiones
  }

  // Mostrar resultados de la API
  mostrarResultadosAPI(libros) {
    const resultsEl = document.getElementById('api-results')
    
    if (libros.length === 0) {
      resultsEl.innerHTML = `
        <div class="api-no-results">
          <h3>📚 No se encontraron libros</h3>
          <p>Intenta con otros términos de búsqueda</p>
        </div>
      `
    } else {
      resultsEl.innerHTML = libros.map(libro => `
        <div class="api-book-result">
          <img src="${libro.portada}" alt="${libro.titulo}" class="api-book-cover" 
               onerror="this.src='https://images.pexels.com/photos/1029141/pexels-photo-1029141.jpeg?auto=compress&cs=tinysrgb&w=300'">
          <div class="api-book-info">
            <div class="api-book-title">${libro.titulo}</div>
            <div class="api-book-author">por ${libro.autor}</div>
            <div class="api-book-details">
              <span class="api-book-genre">${libro.genero}</span>
              ${libro.año ? `<span class="api-book-year">${libro.año}</span>` : ''}
              ${libro.editorial ? `<span class="api-book-publisher">${libro.editorial}</span>` : ''}
              ${libro.paginas ? `<span class="api-book-pages">${libro.paginas} páginas</span>` : ''}
            </div>
            <button class="btn-add-from-api" onclick="biblioteca.agregarDesdeAPI('${libro.id}')">
              Agregar a mi biblioteca
            </button>
          </div>
        </div>
      `).join('')
    }
    
    resultsEl.style.display = 'block'
  }

  // Mostrar error de la API
  mostrarErrorAPI(mensaje) {
    const resultsEl = document.getElementById('api-results')
    resultsEl.innerHTML = `
      <div class="api-error">
        <h3>❌ Error en la búsqueda</h3>
        <p>${mensaje}</p>
        <p>Por favor, intenta nuevamente</p>
      </div>
    `
    resultsEl.style.display = 'block'
  }

  // Agregar libro desde la API
  async agregarDesdeAPI(bookId) {
    try {
      const libro = await this.googleBooksAPI.obtenerDetallesLibro(bookId)
      
      // Verificar si el libro ya existe
      const libroExistente = this.libros.find(l => 
        l.titulo.toLowerCase() === libro.titulo.toLowerCase() && 
        l.autor.toLowerCase() === libro.autor.toLowerCase()
      )
      
      if (libroExistente) {
        this.mostrarMensaje('Este libro ya está en tu biblioteca', 'warning')
        return
      }

      // Crear nuevo libro con ID único
      const nuevoLibro = {
        ...libro,
        id: Date.now() // Reemplazar ID de la API con uno único local
      }

      this.libros.push(nuevoLibro)
      this.guardarLibros()
      this.renderizarLibros()
      this.actualizarEstadisticas()
      
      this.mostrarMensaje('Libro agregado exitosamente desde Google Books', 'success')
      
      // Limpiar búsqueda
      this.cerrarResultadosAPI()
      
    } catch (error) {
      this.mostrarMensaje('Error al agregar el libro: ' + error.message, 'error')
    }
  }

  // Cerrar resultados de la API
  cerrarResultadosAPI() {
    document.getElementById('api-search-input').value = ''
    document.getElementById('api-loading').style.display = 'none'
    document.getElementById('api-results').style.display = 'none'
    document.getElementById('close-api-results').style.display = 'none'
  }

  // Cargar libros del localStorage
  cargarLibros() {
    const librosGuardados = localStorage.getItem('biblioteca-libros')
    if (librosGuardados) {
      return JSON.parse(librosGuardados)
    }
    // Libros de ejemplo
    return [
      {
        id: 1,
        titulo: "Cien años de soledad",
        autor: "Gabriel García Márquez",
        genero: "Realismo mágico",
        año: 1967,
        estado: "disponible",
        portada: "https://images.pexels.com/photos/1029141/pexels-photo-1029141.jpeg?auto=compress&cs=tinysrgb&w=300"
      },
      {
        id: 2,
        titulo: "Don Quijote de la Mancha",
        autor: "Miguel de Cervantes",
        genero: "Novela",
        año: 1605,
        estado: "prestado",
        portada: "https://images.pexels.com/photos/1029141/pexels-photo-1029141.jpeg?auto=compress&cs=tinysrgb&w=300"
      }
    ]
  }

  // Guardar libros en localStorage
  guardarLibros() {
    localStorage.setItem('biblioteca-libros', JSON.stringify(this.libros))
  }

  // Inicializar eventos
  inicializarEventos() {
    // Formulario de agregar libro
    document.getElementById('book-form').addEventListener('submit', (e) => {
      e.preventDefault()
      this.agregarLibro()
    })

    // Vista previa de imagen para agregar libro
    const portadaInput = document.getElementById('portada')
    portadaInput.addEventListener('input', () => {
      this.mostrarVistaPrevia(portadaInput.value, 'preview-add')
    })
    portadaInput.addEventListener('paste', (e) => {
      setTimeout(() => {
        this.mostrarVistaPrevia(portadaInput.value, 'preview-add')
      }, 100)
    })

    // Vista previa de imagen para editar libro
    const editPortadaInput = document.getElementById('edit-portada')
    editPortadaInput.addEventListener('input', () => {
      this.mostrarVistaPrevia(editPortadaInput.value, 'preview-edit')
    })
    editPortadaInput.addEventListener('paste', (e) => {
      setTimeout(() => {
        this.mostrarVistaPrevia(editPortadaInput.value, 'preview-edit')
      }, 100)
    })

    // Búsqueda y filtros
    document.getElementById('search-input').addEventListener('input', () => {
      this.renderizarLibros()
    })

    document.getElementById('filter-estado').addEventListener('change', () => {
      this.renderizarLibros()
    })

    document.getElementById('sort-by').addEventListener('change', () => {
      this.renderizarLibros()
    })

    // Modal de edición
    document.querySelector('.close').addEventListener('click', () => {
      this.cerrarModal()
    })

    document.getElementById('edit-form').addEventListener('submit', (e) => {
      e.preventDefault()
      this.guardarEdicion()
    })

    // Cerrar modal al hacer clic fuera
    window.addEventListener('click', (e) => {
      const modal = document.getElementById('edit-modal')
      if (e.target === modal) {
        this.cerrarModal()
      }
    })

    // Eventos para la búsqueda en API
    const apiSearchInput = document.getElementById('api-search-input')
    apiSearchInput.addEventListener('input', (e) => {
      this.buscarEnAPI(e.target.value)
    })

    document.getElementById('close-api-results').addEventListener('click', () => {
      this.cerrarResultadosAPI()
    })
  }

  // Mostrar vista previa de imagen
  mostrarVistaPrevia(url, previewId) {
    const previewContainer = document.getElementById(previewId)
    
    if (!url || !this.esUrlValida(url)) {
      previewContainer.innerHTML = '<p class="preview-placeholder">Vista previa de la portada aparecerá aquí</p>'
      return
    }

    previewContainer.innerHTML = `
      <div class="image-preview">
        <img src="${url}" alt="Vista previa" 
             onload="this.style.display='block'; this.nextElementSibling.style.display='none';"
             onerror="this.style.display='none'; this.nextElementSibling.style.display='block';"
             style="display: none;">
        <div class="preview-error" style="display: none;">
          <p>❌ No se pudo cargar la imagen</p>
          <p class="error-text">Verifica que la URL sea correcta</p>
        </div>
        <div class="preview-loading">
          <p>⏳ Cargando imagen...</p>
        </div>
      </div>
    `
  }

  // Validar si es una URL válida
  esUrlValida(url) {
    try {
      new URL(url)
      return url.match(/\.(jpeg|jpg|gif|png|webp|svg)$/i) !== null
    } catch {
      return false
    }
  }

  // Agregar nuevo libro
  agregarLibro() {
    const titulo = document.getElementById('titulo').value.trim()
    const autor = document.getElementById('autor').value.trim()
    const genero = document.getElementById('genero').value.trim()
    const año = document.getElementById('año').value
    const portada = document.getElementById('portada').value.trim()
    const estado = document.getElementById('estado').value

    if (!titulo || !autor) {
      alert('Por favor, completa al menos el título y el autor')
      return
    }

    const nuevoLibro = {
      id: Date.now(),
      titulo,
      autor,
      genero: genero || 'Sin género',
      año: año ? parseInt(año) : null,
      portada: portada || 'https://images.pexels.com/photos/1029141/pexels-photo-1029141.jpeg?auto=compress&cs=tinysrgb&w=300',
      estado
    }

    this.libros.push(nuevoLibro)
    this.guardarLibros()
    this.renderizarLibros()
    this.actualizarEstadisticas()
    
    // Limpiar formulario y vista previa
    document.getElementById('book-form').reset()
    document.getElementById('preview-add').innerHTML = '<p class="preview-placeholder">Vista previa de la portada aparecerá aquí</p>'
    
    // Mostrar mensaje de éxito
    this.mostrarMensaje('Libro agregado exitosamente', 'success')
  }

  // Renderizar lista de libros
  renderizarLibros() {
    const container = document.getElementById('books-container')
    const emptyState = document.getElementById('empty-state')
    
    let librosFiltrados = this.filtrarLibros()
    librosFiltrados = this.ordenarLibros(librosFiltrados)

    if (librosFiltrados.length === 0) {
      container.innerHTML = ''
      emptyState.style.display = 'block'
      return
    }

    emptyState.style.display = 'none'
    
    container.innerHTML = librosFiltrados.map(libro => `
      <div class="book-card ${libro.estado}" data-id="${libro.id}">
        <div class="book-cover">
          <img src="${libro.portada}" alt="${libro.titulo}" onerror="this.src='https://images.pexels.com/photos/1029141/pexels-photo-1029141.jpeg?auto=compress&cs=tinysrgb&w=300'">
          <div class="book-status ${libro.estado}">${this.getEstadoTexto(libro.estado)}</div>
        </div>
        <div class="book-info">
          <h3 class="book-title">${libro.titulo}</h3>
          <p class="book-author">por ${libro.autor}</p>
          <div class="book-details">
            <span class="book-genre">${libro.genero}</span>
            ${libro.año ? `<span class="book-year">${libro.año}</span>` : ''}
            ${libro.editorial ? `<span class="book-publisher">${libro.editorial}</span>` : ''}
            ${libro.paginas ? `<span class="book-pages">${libro.paginas} páginas</span>` : ''}
          </div>
          ${libro.descripcion && libro.descripcion !== 'Sin descripción disponible' ? `
            <div class="book-description">
              <p>${libro.descripcion.length > 150 ? libro.descripcion.substring(0, 150) + '...' : libro.descripcion}</p>
            </div>
          ` : ''}
          <div class="book-actions">
            <button class="btn-edit" onclick="biblioteca.editarLibro(${libro.id})">Editar</button>
            <button class="btn-delete" onclick="biblioteca.eliminarLibro(${libro.id})">Eliminar</button>
            <button class="btn-status" onclick="biblioteca.cambiarEstado(${libro.id})">${this.getAccionEstado(libro.estado)}</button>
          </div>
        </div>
      </div>
    `).join('')
  }

  // Filtrar libros según búsqueda y filtros
  filtrarLibros() {
    const searchTerm = document.getElementById('search-input').value.toLowerCase()
    const filterEstado = document.getElementById('filter-estado').value

    return this.libros.filter(libro => {
      const matchesSearch = !searchTerm || 
        libro.titulo.toLowerCase().includes(searchTerm) ||
        libro.autor.toLowerCase().includes(searchTerm) ||
        libro.genero.toLowerCase().includes(searchTerm)
      
      const matchesFilter = !filterEstado || libro.estado === filterEstado

      return matchesSearch && matchesFilter
    })
  }

  // Ordenar libros
  ordenarLibros(libros) {
    const sortBy = document.getElementById('sort-by').value
    
    return [...libros].sort((a, b) => {
      switch (sortBy) {
        case 'titulo':
          return a.titulo.localeCompare(b.titulo)
        case 'autor':
          return a.autor.localeCompare(b.autor)
        case 'año':
          return (b.año || 0) - (a.año || 0)
        default:
          return 0
      }
    })
  }

  // Editar libro
  editarLibro(id) {
    const libro = this.libros.find(l => l.id === id)
    if (!libro) return

    this.libroEditando = libro
    
    // Llenar formulario de edición
    document.getElementById('edit-titulo').value = libro.titulo
    document.getElementById('edit-autor').value = libro.autor
    document.getElementById('edit-genero').value = libro.genero
    document.getElementById('edit-año').value = libro.año || ''
    document.getElementById('edit-portada').value = libro.portada
    document.getElementById('edit-estado').value = libro.estado

    // Mostrar vista previa de la imagen actual
    this.mostrarVistaPrevia(libro.portada, 'preview-edit')

    // Mostrar modal
    document.getElementById('edit-modal').style.display = 'block'
  }

  // Guardar edición
  guardarEdicion() {
    if (!this.libroEditando) return

    const titulo = document.getElementById('edit-titulo').value.trim()
    const autor = document.getElementById('edit-autor').value.trim()
    const genero = document.getElementById('edit-genero').value.trim()
    const año = document.getElementById('edit-año').value
    const portada = document.getElementById('edit-portada').value.trim()
    const estado = document.getElementById('edit-estado').value

    if (!titulo || !autor) {
      alert('Por favor, completa al menos el título y el autor')
      return
    }

    // Actualizar libro
    this.libroEditando.titulo = titulo
    this.libroEditando.autor = autor
    this.libroEditando.genero = genero || 'Sin género'
    this.libroEditando.año = año ? parseInt(año) : null
    this.libroEditando.portada = portada || 'https://images.pexels.com/photos/1029141/pexels-photo-1029141.jpeg?auto=compress&cs=tinysrgb&w=300'
    this.libroEditando.estado = estado

    this.guardarLibros()
    this.renderizarLibros()
    this.actualizarEstadisticas()
    this.cerrarModal()
    
    this.mostrarMensaje('Libro actualizado exitosamente', 'success')
  }

  // Cerrar modal
  cerrarModal() {
    document.getElementById('edit-modal').style.display = 'none'
    this.libroEditando = null
    // Limpiar vista previa
    document.getElementById('preview-edit').innerHTML = '<p class="preview-placeholder">Vista previa de la portada aparecerá aquí</p>'
  }

  // Eliminar libro
  eliminarLibro(id) {
    if (confirm('¿Estás seguro de que quieres eliminar este libro?')) {
      this.libros = this.libros.filter(libro => libro.id !== id)
      this.guardarLibros()
      this.renderizarLibros()
      this.actualizarEstadisticas()
      this.mostrarMensaje('Libro eliminado exitosamente', 'success')
    }
  }

  // Cambiar estado del libro
  cambiarEstado(id) {
    const libro = this.libros.find(l => l.id === id)
    if (!libro) return

    const estados = ['disponible', 'prestado', 'reservado']
    const currentIndex = estados.indexOf(libro.estado)
    const nextIndex = (currentIndex + 1) % estados.length
    
    libro.estado = estados[nextIndex]
    
    this.guardarLibros()
    this.renderizarLibros()
    this.actualizarEstadisticas()
    
    this.mostrarMensaje(`Estado cambiado a: ${this.getEstadoTexto(libro.estado)}`, 'info')
  }

  // Actualizar estadísticas
  actualizarEstadisticas() {
    const total = this.libros.length
    const disponibles = this.libros.filter(l => l.estado === 'disponible').length
    const prestados = this.libros.filter(l => l.estado === 'prestado').length

    document.getElementById('total-libros').textContent = total
    document.getElementById('libros-disponibles').textContent = disponibles
    document.getElementById('libros-prestados').textContent = prestados
  }

  // Obtener texto del estado
  getEstadoTexto(estado) {
    const estados = {
      'disponible': 'Disponible',
      'prestado': 'Prestado',
      'reservado': 'Reservado'
    }
    return estados[estado] || estado
  }

  // Obtener acción del estado
  getAccionEstado(estado) {
    const acciones = {
      'disponible': 'Prestar',
      'prestado': 'Devolver',
      'reservado': 'Liberar'
    }
    return acciones[estado] || 'Cambiar'
  }

  // Mostrar mensaje
  mostrarMensaje(mensaje, tipo = 'info') {
    // Crear elemento de mensaje
    const messageEl = document.createElement('div')
    messageEl.className = `message message-${tipo}`
    messageEl.textContent = mensaje
    
    // Agregar al DOM
    document.body.appendChild(messageEl)
    
    // Mostrar con animación
    setTimeout(() => messageEl.classList.add('show'), 100)
    
    // Remover después de 3 segundos
    setTimeout(() => {
      messageEl.classList.remove('show')
      setTimeout(() => messageEl.remove(), 300)
    }, 3000)
  }
}

// Hacer disponible globalmente para los eventos onclick
import { GoogleBooksAPI } from './api.js'
window.biblioteca = null